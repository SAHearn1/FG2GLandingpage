# Root Work Framework Landing Page

Official landing page for the Root Work Framework - A trauma-informed, healing-centered pedagogy integrating STEAM, Living Learning Labs, and Project-Based Learning.

## About

The Root Work Framework was developed by Dr. Shawn A. Hearn, Ed.D., J.D., founder of Community Exceptional Children's Services (CECS). This framework is grounded in SAMHSA's 6 principles of trauma-informed care and the evidence-based 5Rs methodology.

## Deployment Instructions

### Prerequisites
- A GitHub account
- A Vercel account (free tier works perfectly)
- Git installed on your local machine

### Step 1: Push to GitHub

1. **Initialize Git repository** (if not already done):
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Root Work Framework landing page"
   ```

2. **Create a new repository on GitHub**:
   - Go to https://github.com/new
   - Name it `rootwork-framework` (or your preferred name)
   - Set visibility to Public or Private
   - Do NOT initialize with README, .gitignore, or license
   - Click "Create repository"

3. **Connect and push to GitHub**:
   ```bash
   git remote add origin https://github.com/YOUR-USERNAME/rootwork-framework.git
   git branch -M main
   git push -u origin main
   ```

### Step 2: Deploy to Vercel

#### Option A: Deploy via Vercel Dashboard (Easiest)

1. Go to https://vercel.com and sign in
2. Click "Add New..." → "Project"
3. Import your GitHub repository
4. Vercel will auto-detect it as a static site
5. Click "Deploy"
6. Your site will be live at `https://your-project-name.vercel.app`

#### Option B: Deploy via Vercel CLI

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Deploy:
   ```bash
   vercel
   ```

3. Follow the prompts to link your project

### Step 3: Custom Domain (Optional)

1. In Vercel Dashboard, go to your project
2. Click "Settings" → "Domains"
3. Add your custom domain
4. Follow DNS configuration instructions

## Project Structure

```
rootwork-deployment/
├── index.html          # Main landing page
├── vercel.json        # Vercel configuration
├── README.md          # This file
└── .gitignore         # Git ignore rules
```

## Features

- **Responsive Design**: Mobile-first, works on all devices
- **Brand Standards**: Official Root Work Framework colors and typography
- **Embedded Logo**: High-quality Emblem of Knowledge and Balance
- **SAMHSA-Aligned**: Built on trauma-informed care principles
- **SEO Optimized**: Proper meta tags and semantic HTML

## Local Development

To view locally, simply open `index.html` in your web browser, or use a local server:

```bash
# Using Python
python -m http.server 8000

# Using Node.js
npx serve
```

Then navigate to `http://localhost:8000`

## Updates

To update the deployed site:

1. Make changes to `index.html`
2. Commit changes:
   ```bash
   git add .
   git commit -m "Description of changes"
   git push
   ```
3. Vercel will automatically redeploy

## Contact

For questions about the Root Work Framework:
- Website: (coming soon)
- Email: hearn.sa@gmail.com
- LinkedIn: https://www.linkedin.com/in/dr-shawn-a-hearn/

## License

© 2025 Root Work Framework. All rights reserved. Dr. Shawn A. Hearn, Ed.D., J.D.
