# Quick Deployment Guide

Follow these steps to deploy your Root Work Framework landing page to Vercel.

## 🚀 Quick Start (5 Minutes)

### Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Repository name: `rootwork-framework`
3. Description: "Root Work Framework Landing Page"
4. Choose Public or Private
5. **Do NOT** check any boxes (no README, .gitignore, or license)
6. Click "Create repository"

### Step 2: Upload to GitHub

Open your terminal/command prompt and navigate to this folder, then run:

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit: Root Work Framework landing page"

# Connect to GitHub (replace YOUR-USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR-USERNAME/rootwork-framework.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Step 3: Deploy to Vercel

1. **Sign up/Login to Vercel**
   - Go to https://vercel.com
   - Click "Sign Up" (or "Login" if you have an account)
   - Choose "Continue with GitHub"

2. **Import Your Project**
   - Click "Add New..." button
   - Select "Project"
   - Find your `rootwork-framework` repository
   - Click "Import"

3. **Configure & Deploy**
   - Project Name: `rootwork-framework` (or customize)
   - Framework Preset: Leave as detected (or select "Other")
   - Root Directory: `./`
   - Build Command: (leave empty)
   - Output Directory: (leave empty)
   - Click "Deploy"

4. **Wait for Deployment** (usually 30-60 seconds)
   - Vercel will build and deploy your site
   - You'll get a URL like: `https://rootwork-framework.vercel.app`

### Step 4: Visit Your Live Site! 🎉

Your site is now live! Share the URL with colleagues, clients, or partners.

## 📝 Making Updates

Whenever you want to update your site:

```bash
# Make your changes to index.html
# Then:
git add .
git commit -m "Describe your changes"
git push
```

Vercel will automatically detect the changes and redeploy your site within a minute!

## 🌐 Custom Domain (Optional)

To use your own domain (e.g., rootworkframework.com):

1. In Vercel Dashboard, click on your project
2. Go to "Settings" → "Domains"
3. Click "Add Domain"
4. Enter your domain name
5. Follow the DNS configuration instructions

You'll need to add DNS records at your domain registrar (GoDaddy, Namecheap, etc.).

## 🆘 Troubleshooting

### "Permission denied" error when pushing to GitHub
- Make sure you're authenticated with GitHub
- Try: `git remote set-url origin https://YOUR-USERNAME@github.com/YOUR-USERNAME/rootwork-framework.git`

### Vercel deployment failed
- Check that `index.html` is in the root directory
- Ensure `vercel.json` is properly formatted
- Check Vercel's deployment logs for specific errors

### Site looks different on Vercel than locally
- Hard refresh the page (Ctrl+Shift+R or Cmd+Shift+R)
- Clear browser cache
- Check browser console for errors

## 📞 Need Help?

- Vercel Documentation: https://vercel.com/docs
- GitHub Documentation: https://docs.github.com
- Email: hearn.sa@gmail.com

---

**Pro Tip**: Bookmark your Vercel dashboard URL for easy access to deployment logs and analytics!
